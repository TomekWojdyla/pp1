#23.	In ski jumping competitions, each competitor is assessed by five judges. Each judge can award a score from 0 to 20 points. The highest and lowest scores are discarded. The remaining three scores are added up to form the final score obtained by the competitor. The ratings of four players are presented below.
#[(17,15,16,17,15),
# (16,18,19,17,19),
# (19,15,15,19,18),
# (18,17,19,15,16)]
#Calculate and display the total points obtained by competitors. Tip: use the Python built-in functions: map(), sum(), min(), max(). Sample result:
#[48, 54, 52, 51]


judges = [(17,15,16,17,15),
 (16,18,19,17,19),
 (19,15,15,19,18),
 (18,17,19,15,16)]

judges_new=[]

for i in range(4):
    a = min(judges[i])
    b = max(judges[i])
    check1 = False
    check2 = False
    judges_new.append([])
    for j in range(5):
        if judges[i][j]==a and check1 == False:
            check1 = True
        elif judges[i][j]==b and check2==False:
            check2 = True
        else:
            judges_new[i].append(judges[i][j])

scores = []
for i in range(4):
    scores = list(map(lambda x: (x[0]+x[1]+x[2]), judges_new))

print(judges_new)
print(scores)